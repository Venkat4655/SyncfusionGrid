import { Component } from '@angular/core';

@Component({
    selector: 'ej-app',
    templateUrl: 'src/grid/grid.component.html',
})
export class GridComponent {
    public data1: any;
     public data2: any;
      public data3: any;
      
   
    public position;
    public Dialog2position;
   public Dialog3position;
    constructor() {
        
        this.position = {X:30,Y:60};
        this.Dialog2position={X:700, Y:60};
        this.Dialog3position={X:350, Y:550};
	      
        this.data1 = ej.DataManager({url: "http://mvc.syncfusion.com/Services/Northwnd.svc/Orders"});
        this.data2= ej.DataManager({url: "http://mvc.syncfusion.com/Services/Northwnd.svc/Order_Details"});
        this.data3=ej.DataManager({ url: "http://mvc.syncfusion.com/Services/Northwnd.svc/Employees"});
    }
}
